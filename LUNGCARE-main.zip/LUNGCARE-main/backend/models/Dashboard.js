const sql = require('../config/database');

const Dashboard = {
  async createData(userId, dataPayload) {
    const { title, data_type, description, data_values } = dataPayload;
    const result = await sql`
      INSERT INTO dashboard_data (user_id, title, data_type, description, data_values)
      VALUES (${userId}, ${title}, ${data_type}, ${description}, ${JSON.stringify(data_values)})
      RETURNING *
    `;
    return result[0];
  },

  async getUserData(userId) {
    return await sql`
      SELECT * FROM dashboard_data
      WHERE user_id = ${userId}
      ORDER BY created_at DESC
    `;
  },

  async getDataById(id) {
    const result = await sql`
      SELECT * FROM dashboard_data WHERE id = ${id}
    `;
    return result[0];
  },

  async updateData(id, updatePayload) {
    const { title, description, data_values } = updatePayload;
    const result = await sql`
      UPDATE dashboard_data
      SET title = ${title}, description = ${description}, 
          data_values = ${JSON.stringify(data_values)}, updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING *
    `;
    return result[0];
  },

  async deleteData(id) {
    await sql`DELETE FROM dashboard_data WHERE id = ${id}`;
    return { message: 'Dashboard data deleted' };
  },

  async searchData(userId, query) {
    return await sql`
      SELECT * FROM dashboard_data
      WHERE user_id = ${userId} AND (title ILIKE ${'%' + query + '%'} OR description ILIKE ${'%' + query + '%'})
      ORDER BY created_at DESC
    `;
  }
};

module.exports = Dashboard;
