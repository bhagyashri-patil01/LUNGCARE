const sql = require('../config/database');

const FileUpload = {
  async create(userId, fileData) {
    const { file_name, file_path, file_size, file_type } = fileData;
    const result = await sql`
      INSERT INTO file_uploads (user_id, file_name, file_path, file_size, file_type)
      VALUES (${userId}, ${file_name}, ${file_path}, ${file_size}, ${file_type})
      RETURNING *
    `;
    return result[0];
  },

  async getUserFiles(userId) {
    return await sql`
      SELECT * FROM file_uploads
      WHERE user_id = ${userId}
      ORDER BY uploaded_at DESC
    `;
  },

  async deleteFile(fileId) {
    await sql`DELETE FROM file_uploads WHERE id = ${fileId}`;
    return { message: 'File deleted' };
  },

  async getAllFiles() {
    return await sql`
      SELECT * FROM file_uploads
      ORDER BY uploaded_at DESC
    `;
  }
};

module.exports = FileUpload;
