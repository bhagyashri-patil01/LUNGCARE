const sql = require('../config/database');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const User = {
  async create(userData) {
    const { username, email, password, full_name } = userData;
    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await sql`
      INSERT INTO users (username, email, password, full_name)
      VALUES (${username}, ${email}, ${hashedPassword}, ${full_name})
      RETURNING id, username, email, full_name, is_admin, created_at
    `;
    return result[0];
  },

  async findByEmail(email) {
    const result = await sql`
      SELECT * FROM users WHERE email = ${email}
    `;
    return result[0];
  },

  async findById(id) {
    const result = await sql`
      SELECT id, username, email, full_name, avatar_url, is_admin, created_at
      FROM users WHERE id = ${id}
    `;
    return result[0];
  },

  async updateProfile(userId, profileData) {
    const { full_name, avatar_url } = profileData;
    const result = await sql`
      UPDATE users
      SET full_name = ${full_name}, avatar_url = ${avatar_url}
      WHERE id = ${userId}
      RETURNING id, username, email, full_name, avatar_url
    `;
    return result[0];
  },

  async getAllUsers() {
    return await sql`
      SELECT id, username, email, full_name, is_admin, created_at
      FROM users
      ORDER BY created_at DESC
    `;
  },

  async deleteUser(userId) {
    await sql`DELETE FROM users WHERE id = ${userId}`;
    return { message: 'User deleted' };
  }
};

module.exports = User;
