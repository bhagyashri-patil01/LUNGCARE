const sql = require('../config/database');

const Notification = {
  async create(userId, notificationData) {
    const { title, message, type } = notificationData;
    const result = await sql`
      INSERT INTO notifications (user_id, title, message, type)
      VALUES (${userId}, ${title}, ${message}, ${type})
      RETURNING *
    `;
    return result[0];
  },

  async getUserNotifications(userId) {
    return await sql`
      SELECT * FROM notifications
      WHERE user_id = ${userId}
      ORDER BY created_at DESC
      LIMIT 50
    `;
  },

  async markAsRead(notificationId) {
    const result = await sql`
      UPDATE notifications
      SET is_read = true
      WHERE id = ${notificationId}
      RETURNING *
    `;
    return result[0];
  },

  async deleteNotification(notificationId) {
    await sql`DELETE FROM notifications WHERE id = ${notificationId}`;
    return { message: 'Notification deleted' };
  },

  async getUnreadCount(userId) {
    const result = await sql`
      SELECT COUNT(*) as count FROM notifications
      WHERE user_id = ${userId} AND is_read = false
    `;
    return result[0].count;
  }
};

module.exports = Notification;
