const Notification = require('../models/Notification');

const notificationController = {
  async createNotification(req, res) {
    try {
      const result = await Notification.create(req.user.id, req.body);
      res.status(201).json(result);
    } catch (error) {
      console.error('Create notification error:', error);
      res.status(500).json({ error: 'Failed to create notification' });
    }
  },

  async getUserNotifications(req, res) {
    try {
      const notifications = await Notification.getUserNotifications(req.user.id);
      res.json(notifications);
    } catch (error) {
      console.error('Get notifications error:', error);
      res.status(500).json({ error: 'Failed to fetch notifications' });
    }
  },

  async markAsRead(req, res) {
    try {
      const result = await Notification.markAsRead(req.params.id);
      res.json(result);
    } catch (error) {
      console.error('Mark as read error:', error);
      res.status(500).json({ error: 'Failed to mark notification as read' });
    }
  },

  async deleteNotification(req, res) {
    try {
      const result = await Notification.deleteNotification(req.params.id);
      res.json(result);
    } catch (error) {
      console.error('Delete notification error:', error);
      res.status(500).json({ error: 'Failed to delete notification' });
    }
  },

  async getUnreadCount(req, res) {
    try {
      const count = await Notification.getUnreadCount(req.user.id);
      res.json({ unread_count: count });
    } catch (error) {
      console.error('Get unread count error:', error);
      res.status(500).json({ error: 'Failed to get unread count' });
    }
  }
};

module.exports = notificationController;
