const FileUpload = require('../models/FileUpload');

const fileController = {
  async uploadFile(req, res) {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No file provided' });
      }

      const fileData = {
        file_name: req.file.originalname,
        file_path: req.file.path,
        file_size: req.file.size,
        file_type: req.file.mimetype
      };

      const result = await FileUpload.create(req.user.id, fileData);
      res.status(201).json(result);
    } catch (error) {
      console.error('Upload file error:', error);
      res.status(500).json({ error: 'Failed to upload file' });
    }
  },

  async getUserFiles(req, res) {
    try {
      const files = await FileUpload.getUserFiles(req.user.id);
      res.json(files);
    } catch (error) {
      console.error('Get files error:', error);
      res.status(500).json({ error: 'Failed to fetch files' });
    }
  },

  async deleteFile(req, res) {
    try {
      const result = await FileUpload.deleteFile(req.params.id);
      res.json(result);
    } catch (error) {
      console.error('Delete file error:', error);
      res.status(500).json({ error: 'Failed to delete file' });
    }
  },

  async getAllFiles(req, res) {
    try {
      const files = await FileUpload.getAllFiles();
      res.json(files);
    } catch (error) {
      console.error('Get all files error:', error);
      res.status(500).json({ error: 'Failed to fetch files' });
    }
  }
};

module.exports = fileController;
