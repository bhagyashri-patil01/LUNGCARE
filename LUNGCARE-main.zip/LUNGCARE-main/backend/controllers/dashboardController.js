const Dashboard = require('../models/Dashboard');

const dashboardController = {
  async createData(req, res) {
    try {
      const result = await Dashboard.createData(req.user.id, req.body);
      res.status(201).json(result);
    } catch (error) {
      console.error('Create data error:', error);
      res.status(500).json({ error: 'Failed to create dashboard data' });
    }
  },

  async getUserData(req, res) {
    try {
      const data = await Dashboard.getUserData(req.user.id);
      res.json(data);
    } catch (error) {
      console.error('Get data error:', error);
      res.status(500).json({ error: 'Failed to fetch dashboard data' });
    }
  },

  async getDataById(req, res) {
    try {
      const data = await Dashboard.getDataById(req.params.id);
      if (!data) {
        return res.status(404).json({ error: 'Data not found' });
      }
      res.json(data);
    } catch (error) {
      console.error('Get data by id error:', error);
      res.status(500).json({ error: 'Failed to fetch data' });
    }
  },

  async updateData(req, res) {
    try {
      const updated = await Dashboard.updateData(req.params.id, req.body);
      res.json(updated);
    } catch (error) {
      console.error('Update data error:', error);
      res.status(500).json({ error: 'Failed to update data' });
    }
  },

  async deleteData(req, res) {
    try {
      const result = await Dashboard.deleteData(req.params.id);
      res.json(result);
    } catch (error) {
      console.error('Delete data error:', error);
      res.status(500).json({ error: 'Failed to delete data' });
    }
  },

  async searchData(req, res) {
    try {
      const { query } = req.query;
      if (!query) {
        return res.status(400).json({ error: 'Search query required' });
      }
      const results = await Dashboard.searchData(req.user.id, query);
      res.json(results);
    } catch (error) {
      console.error('Search error:', error);
      res.status(500).json({ error: 'Search failed' });
    }
  }
};

module.exports = dashboardController;
