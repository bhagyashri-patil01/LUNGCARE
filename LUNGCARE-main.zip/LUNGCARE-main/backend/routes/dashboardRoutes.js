const express = require('express');
const dashboardController = require('../controllers/dashboardController');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

router.post('/data', authenticateToken, dashboardController.createData);
router.get('/data', authenticateToken, dashboardController.getUserData);
router.get('/data/:id', authenticateToken, dashboardController.getDataById);
router.put('/data/:id', authenticateToken, dashboardController.updateData);
router.delete('/data/:id', authenticateToken, dashboardController.deleteData);
router.get('/search', authenticateToken, dashboardController.searchData);

module.exports = router;
