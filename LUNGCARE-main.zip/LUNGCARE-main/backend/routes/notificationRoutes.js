const express = require('express');
const notificationController = require('../controllers/notificationController');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

router.post('/', authenticateToken, notificationController.createNotification);
router.get('/', authenticateToken, notificationController.getUserNotifications);
router.put('/:id', authenticateToken, notificationController.markAsRead);
router.delete('/:id', authenticateToken, notificationController.deleteNotification);
router.get('/count/unread', authenticateToken, notificationController.getUnreadCount);

module.exports = router;
