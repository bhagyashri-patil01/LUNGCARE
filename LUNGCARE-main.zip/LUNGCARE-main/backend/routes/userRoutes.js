const express = require('express');
const User = require('../models/User');
const { authenticateToken, authorizeAdmin } = require('../middleware/auth');

const router = express.Router();

// Admin only: Get all users
router.get('/', authenticateToken, authorizeAdmin, async (req, res) => {
  try {
    const users = await User.getAllUsers();
    res.json(users);
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// Admin only: Delete user
router.delete('/:id', authenticateToken, authorizeAdmin, async (req, res) => {
  try {
    const result = await User.deleteUser(req.params.id);
    res.json(result);
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

module.exports = router;
