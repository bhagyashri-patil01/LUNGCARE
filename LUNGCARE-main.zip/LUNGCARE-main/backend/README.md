# Backend API Server

Full-featured analytics backend built with Node.js, Express, and PostgreSQL.

## Features

- ✅ User authentication & authorization with JWT
- ✅ Role-based access control (Admin/User)
- ✅ Real-time notifications via Socket.io
- ✅ RESTful API endpoints
- ✅ Database models for Users, Dashboard Data, Notifications, Files
- ✅ Error handling & validation
- ✅ CORS support

## Quick Start

### Install Dependencies
```bash
npm install
```

### Environment Setup
Create `.env` file with:
```env
PORT=5000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=dashboard_db
DB_USER=postgres
DB_PASSWORD=your_password
JWT_SECRET=your_secret_key
NODE_ENV=development
```

### Run Server
```bash
npm run dev
```

## Project Structure

```
backend/
├── config/          # Database configuration
├── controllers/     # Request handlers
├── middleware/      # Authentication, validation
├── models/          # Database models
├── routes/          # API routes
├── server.js        # Express server setup
└── package.json
```

## API Endpoints

See [API Documentation](../DEPLOYMENT.md) for detailed endpoints.

## Technologies

- **Express.js** - Web framework
- **PostgreSQL** - Database
- **Socket.io** - Real-time communication
- **JWT** - Authentication
- **Bcrypt** - Password hashing
