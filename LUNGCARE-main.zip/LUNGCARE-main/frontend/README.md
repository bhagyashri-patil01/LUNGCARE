# Frontend React Application

Modern, responsive React dashboard built with React 18, Tailwind CSS, and Recharts.

## Features

- ✅ Responsive design (Mobile, Tablet, Desktop)
- ✅ User authentication & profile management
- ✅ Real-time dashboard with charts
- ✅ File upload functionality
- ✅ Search & filtering
- ✅ Admin panel
- ✅ Real-time notifications

## Quick Start

### Install Dependencies
```bash
npm install
```

### Environment Setup
Create `.env` file with:
```env
REACT_APP_API_URL=http://localhost:5000
```

### Run Development Server
```bash
npm start
```

Application will open at `http://localhost:3000`

### Build for Production
```bash
npm run build
```

## Project Structure

```
frontend/
├── public/              # Static files
├── src/
│   ├── components/      # Reusable components
│   ├── pages/           # Page components
│   ├── styles/          # CSS files
│   ├── utils/           # Utility functions & APIs
│   ├── App.jsx          # Main app component
│   └── index.jsx        # Entry point
└── package.json
```

## Key Components

- **Login/Register Pages** - User authentication
- **Dashboard Page** - Main analytics view with charts
- **Profile Page** - User profile management
- **Admin Page** - System administration
- **Sidebar & Navbar** - Navigation components
- **Chart Components** - Recharts integration
- **File Upload** - Dropzone integration

## Technologies

- **React 18** - UI library
- **React Router** - Client-side routing
- **Axios** - HTTP client
- **Socket.io** - Real-time communication
- **Recharts** - Data visualization
- **Zustand** - State management
- **Tailwind CSS** - Styling

## Responsive Breakpoints

- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px
