import React from 'react';
import '../styles/Sidebar.css';

const Sidebar = ({ user, logout }) => {
  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <h2>Dashboard</h2>
      </div>
      <nav className="sidebar-nav">
        <a href="/" className="nav-item">
          <span className="icon">📊</span>
          <span>Dashboard</span>
        </a>
        <a href="/profile" className="nav-item">
          <span className="icon">👤</span>
          <span>Profile</span>
        </a>
        {user?.is_admin && (
          <a href="/admin" className="nav-item">
            <span className="icon">⚙️</span>
            <span>Admin</span>
          </a>
        )}
      </nav>
      <div className="sidebar-footer">
        <button onClick={logout} className="logout-btn">
          Logout
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
