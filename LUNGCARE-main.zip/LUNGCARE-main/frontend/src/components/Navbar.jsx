import React, { useState, useEffect } from 'react';
import '../styles/Navbar.css';
import { initializeSocket, getSocket } from '../utils/socket';

const Navbar = ({ user, logout }) => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    if (user) {
      const socket = initializeSocket(user.id);
      
      socket.on('new_notification', (notification) => {
        setNotifications(prev => [notification, ...prev]);
        setUnreadCount(prev => prev + 1);
      });
    }
  }, [user]);

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <h1>LungCare Analytics</h1>
      </div>
      <div className="navbar-right">
        <div className="notification-bell" onClick={() => setShowNotifications(!showNotifications)}>
          <span className="bell-icon">🔔</span>
          {unreadCount > 0 && <span className="badge">{unreadCount}</span>}
        </div>
        
        {showNotifications && (
          <div className="notifications-dropdown">
            {notifications.length > 0 ? (
              notifications.slice(0, 5).map((notif, idx) => (
                <div key={idx} className="notification-item">
                  <h4>{notif.title}</h4>
                  <p>{notif.message}</p>
                </div>
              ))
            ) : (
              <p className="no-notifications">No notifications</p>
            )}
          </div>
        )}

        <div className="user-menu">
          <span className="user-name">{user?.full_name || user?.username}</span>
          <img src={user?.avatar_url || '/default-avatar.png'} alt="User" className="user-avatar" />
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
