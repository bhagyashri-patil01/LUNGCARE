import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import '../styles/FileUpload.css';

const FileUpload = ({ onUpload }) => {
  const [uploading, setUploading] = useState(false);

  const onDrop = useCallback(acceptedFiles => {
    acceptedFiles.forEach(file => {
      const reader = new FileReader();
      reader.onload = () => {
        onUpload(file);
      };
      reader.readAsArrayBuffer(file);
    });
  }, [onUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  return (
    <div {...getRootProps()} className={`file-upload ${isDragActive ? 'active' : ''}`}>
      <input {...getInputProps()} />
      {isDragActive ? (
        <p>Drop the files here...</p>
      ) : (
        <div>
          <p>📁 Drag and drop files here</p>
          <p>or click to select files</p>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
