import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:5000';

const dashboardService = {
  // Dashboard Data
  async createData(payload) {
    return await axios.post(`${API_BASE}/api/dashboard/data`, payload);
  },

  async getUserData() {
    return await axios.get(`${API_BASE}/api/dashboard/data`);
  },

  async updateData(id, payload) {
    return await axios.put(`${API_BASE}/api/dashboard/data/${id}`, payload);
  },

  async deleteData(id) {
    return await axios.delete(`${API_BASE}/api/dashboard/data/${id}`);
  },

  async searchData(query) {
    return await axios.get(`${API_BASE}/api/dashboard/search?query=${query}`);
  },

  // Files
  async uploadFile(file) {
    const formData = new FormData();
    formData.append('file', file);
    return await axios.post(`${API_BASE}/api/files/upload`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },

  async getUserFiles() {
    return await axios.get(`${API_BASE}/api/files`);
  },

  async deleteFile(id) {
    return await axios.delete(`${API_BASE}/api/files/${id}`);
  },

  // Notifications
  async getNotifications() {
    return await axios.get(`${API_BASE}/api/notifications`);
  },

  async markNotificationAsRead(id) {
    return await axios.put(`${API_BASE}/api/notifications/${id}`);
  },

  async deleteNotification(id) {
    return await axios.delete(`${API_BASE}/api/notifications/${id}`);
  }
};

export default dashboardService;
