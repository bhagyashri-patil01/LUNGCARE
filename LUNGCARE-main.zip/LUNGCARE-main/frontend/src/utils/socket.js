import io from 'socket.io-client';

const SOCKET_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

let socket = null;

export const initializeSocket = (userId) => {
  if (socket) return socket;

  socket = io(SOCKET_URL, {
    auth: {
      token: localStorage.getItem('token')
    }
  });

  socket.emit('join_room', userId);
  return socket;
};

export const getSocket = () => socket;

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};
