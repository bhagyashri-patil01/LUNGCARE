import React, { useState, useEffect } from 'react';
import Card from '../components/Card';
import ChartComponent from '../components/ChartComponent';
import FileUpload from '../components/FileUpload';
import api from '../utils/api';
import '../styles/DashboardPage.css';

const DashboardPage = () => {
  const [dashboardData, setDashboardData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await api.get('/api/dashboard/data');
      setDashboardData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    try {
      const response = await api.get(`/api/dashboard/search?query=${searchQuery}`);
      setDashboardData(response.data);
    } catch (error) {
      console.error('Search error:', error);
    }
  };

  const handleFileUpload = async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      await api.post('/api/files/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      // Refresh dashboard after upload
      fetchDashboardData();
    } catch (error) {
      console.error('File upload error:', error);
    }
  };

  // Sample chart data
  const sampleLineData = [
    { name: 'Jan', value: 400 },
    { name: 'Feb', value: 300 },
    { name: 'Mar', value: 200 },
    { name: 'Apr', value: 278 },
    { name: 'May', value: 190 },
  ];

  const samplePieData = [
    { name: 'Malignant', value: 87 },
    { name: 'Benign', value: 10 },
    { name: 'Indeterminate', value: 3 },
  ];

  if (loading) return <div className="loading">Loading dashboard...</div>;

  return (
    <div className="dashboard-page">
      <div className="dashboard-header">
        <h1>Dashboard</h1>
        <form onSubmit={handleSearch} className="search-form">
          <input
            type="text"
            placeholder="Search data..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button type="submit">Search</button>
        </form>
      </div>

      <div className="dashboard-grid">
        <Card title="Data Visualization - Line Chart">
          <ChartComponent type="line" data={sampleLineData} title="Performance Over Time" />
        </Card>

        <Card title="Classification Results">
          <ChartComponent type="pie" data={samplePieData} title="Diagnosis Distribution" />
        </Card>

        <Card title="File Upload">
          <FileUpload onUpload={handleFileUpload} />
        </Card>

        <Card title="Recent Data">
          <div className="data-list">
            {dashboardData.length > 0 ? (
              dashboardData.map(item => (
                <div key={item.id} className="data-item">
                  <h4>{item.title}</h4>
                  <p>{item.description}</p>
                  <small>{new Date(item.created_at).toLocaleDateString()}</small>
                </div>
              ))
            ) : (
              <p>No data available</p>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default DashboardPage;
