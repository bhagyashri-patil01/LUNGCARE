import React, { useState, useEffect } from 'react';
import Card from '../components/Card';
import api from '../utils/api';
import '../styles/AdminPage.css';

const AdminPage = () => {
  const [users, setUsers] = useState([]);
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('users');

  useEffect(() => {
    fetchAdminData();
  }, []);

  const fetchAdminData = async () => {
    try {
      if (activeTab === 'users') {
        // Fetch users from backend
        const response = await api.get('/api/auth/users'); // Would need to create this endpoint
        setUsers(response.data);
      } else if (activeTab === 'files') {
        const response = await api.get('/api/files/all');
        setFiles(response.data);
      }
    } catch (error) {
      console.error('Error fetching admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setLoading(true);
  };

  return (
    <div className="admin-page">
      <h1>Admin Panel</h1>
      
      <div className="admin-tabs">
        <button 
          className={`tab ${activeTab === 'users' ? 'active' : ''}`}
          onClick={() => handleTabChange('users')}
        >
          Users
        </button>
        <button 
          className={`tab ${activeTab === 'files' ? 'active' : ''}`}
          onClick={() => handleTabChange('files')}
        >
          Files
        </button>
      </div>

      <Card>
        {loading ? (
          <div className="loading">Loading...</div>
        ) : activeTab === 'users' ? (
          <div className="admin-table">
            <h3>System Users</h3>
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Full Name</th>
                  <th>Admin</th>
                  <th>Joined</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>{user.username}</td>
                    <td>{user.email}</td>
                    <td>{user.full_name}</td>
                    <td>{user.is_admin ? 'Yes' : 'No'}</td>
                    <td>{new Date(user.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="admin-table">
            <h3>Uploaded Files</h3>
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>File Name</th>
                  <th>Size</th>
                  <th>Type</th>
                  <th>Uploaded</th>
                </tr>
              </thead>
              <tbody>
                {files.map(file => (
                  <tr key={file.id}>
                    <td>{file.id}</td>
                    <td>{file.file_name}</td>
                    <td>{(file.file_size / 1024).toFixed(2)} KB</td>
                    <td>{file.file_type}</td>
                    <td>{new Date(file.uploaded_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
};

export default AdminPage;
