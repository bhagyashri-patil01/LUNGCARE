import React, { useState, useEffect } from 'react';
import Card from '../components/Card';
import api from '../utils/api';
import '../styles/ProfilePage.css';

const ProfilePage = () => {
  const [profile, setProfile] = useState(null);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await api.get('/api/auth/profile');
      setProfile(response.data);
      setFormData(response.data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await api.put('/api/auth/profile', {
        full_name: formData.full_name,
        avatar_url: formData.avatar_url
      });
      setProfile(response.data);
      setEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  if (loading) return <div className="loading">Loading profile...</div>;

  return (
    <div className="profile-page">
      <Card title="User Profile">
        {editing ? (
          <form onSubmit={handleSubmit} className="profile-form">
            <div className="form-group">
              <label>Full Name</label>
              <input
                type="text"
                name="full_name"
                value={formData.full_name || ''}
                onChange={handleChange}
              />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                value={formData.email || ''}
                disabled
              />
            </div>
            <div className="form-group">
              <label>Avatar URL</label>
              <input
                type="text"
                name="avatar_url"
                value={formData.avatar_url || ''}
                onChange={handleChange}
                placeholder="https://..."
              />
            </div>
            <button type="submit" className="save-btn">Save Changes</button>
            <button type="button" className="cancel-btn" onClick={() => setEditing(false)}>Cancel</button>
          </form>
        ) : (
          <div className="profile-view">
            <div className="profile-header">
              <img src={profile?.avatar_url || '/default-avatar.png'} alt="Profile" className="profile-avatar" />
              <div className="profile-info">
                <h2>{profile?.full_name || profile?.username}</h2>
                <p>{profile?.email}</p>
              </div>
            </div>
            <button onClick={() => setEditing(true)} className="edit-btn">Edit Profile</button>
          </div>
        )}
      </Card>
    </div>
  );
};

export default ProfilePage;
